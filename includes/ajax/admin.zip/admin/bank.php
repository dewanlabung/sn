<?php

/**
 * ajax -> admin -> bank
 * 
 * @package Sngine
 * @author Zamblek
 */

// fetch bootstrap
require('../../../bootstrap.php');

// check AJAX Request
is_ajax();

// check admin|moderator permission
admin_access('mods_payments_permission');

// valid inputs
if (!isset($_POST['id']) || !is_numeric($_POST['id'])) {
  _error(400);
}

// check demo account
if ($user->_data['user_demo']) {
  modal("ERROR", __("Demo Restriction"), __("You can't do this with demo account"));
}

// handle bank transfers
try {

  /* get the request */
  $get_transfer_request = $db->query(sprintf("SELECT * FROM bank_transfers WHERE transfer_id = %s", secure($_POST['id'], 'int')));
  if ($get_transfer_request->num_rows == 0) {
    _error(400);
  }
  $transfer_request = $get_transfer_request->fetch_assoc();

  switch ($_POST['action']) {
    case 'accept':
      /* process the request */
      switch ($transfer_request['handle']) {
        case 'packages':
          if (!method_exists($user, 'get_package') || !method_exists($user, 'update_user_package')) {
            throw new Exception(__("Payments & Monetization module is not installed"));
          }
          /* check package */
          $package = $user->get_package($transfer_request['package_id']);
          if (!$package) {
            _error(400);
          }
          /* update user package */
          $user->update_user_package($package, $transfer_request['user_id']);
          /* log payment */
          $user->log_payment($transfer_request['user_id'], $package['price'], 'bank', 'packages');
          break;

        case 'wallet':
          if (!method_exists($user, 'wallet_update_balance') || !method_exists($user, 'wallet_set_transaction')) {
            throw new Exception(__("Payments & Monetization module is not installed"));
          }
          /* update user wallet balance */
          $user->wallet_update_balance($transfer_request['price'], '+', $transfer_request['user_id']);
          /* wallet transaction */
          $user->wallet_set_transaction($transfer_request['user_id'], 'recharge', 0, $transfer_request['price'], 'in');
          /* log payment */
          $user->log_payment($transfer_request['user_id'], $transfer_request['price'], 'bank', 'wallet');
          break;

        case 'donate':
          if (!method_exists($user, 'funding_donation')) {
            throw new Exception(__("Payments & Monetization module is not installed"));
          }
          /* funding donation */
          $user->funding_donation($transfer_request['post_id'], $transfer_request['price'], $transfer_request['user_id']);
          /* log payment */
          $user->log_payment($transfer_request['user_id'], $transfer_request['price'], 'bank', 'donate');
          break;

        case 'subscribe':
          if (!method_exists($user, 'get_monetization_plan') || !method_exists($user, 'subscribe')) {
            throw new Exception(__("Payments & Monetization module is not installed"));
          }
          /* get monetization plan */
          $monetization_plan = $user->get_monetization_plan($transfer_request['plan_id'], true);
          if (!$monetization_plan) {
            _error(400);
          }
          /* subscribe to node */
          $user->subscribe($transfer_request['plan_id'], $transfer_request['user_id']);
          /* log payment */
          $price = (isset($monetization_plan['discounted_price']) && $monetization_plan['discounted_price'] > 0) ? $monetization_plan['discounted_price'] : $monetization_plan['price'];
          $user->log_payment($transfer_request['user_id'], $price, 'bank', 'subscribe');
          break;

        case 'paid_post':
          if (!method_exists($user, 'unlock_paid_post')) {
            throw new Exception(__("Payments & Monetization module is not installed"));
          }
          /* unlock paid post */
          $user->unlock_paid_post($transfer_request['post_id'], $transfer_request['user_id']);
          /* log payment */
          $price = (isset($post['post_price_discounted']) && $post['post_price_discounted'] > 0) ? $post['post_price_discounted'] : $post['post_price'];
          $user->log_payment($transfer_request['user_id'], $price, 'bank', 'paid_post');
          break;

        case 'paid_message':
          if (!method_exists($user, 'unlock_paid_message')) {
            throw new Exception(__("Payments & Monetization module is not installed"));
          }
          /* unlock paid message */
          $message_link = $user->unlock_paid_message($transfer_request['post_id'], $transfer_request['user_id']);
          /* log payment */
          $message = $user->get_conversation_message_by_id($transfer_request['post_id']);
          $price = (isset($message['message_price_discounted']) && $message['message_price_discounted'] > 0) ? $message['message_price_discounted'] : $message['message_price'];
          $user->log_payment($transfer_request['user_id'], $price, 'bank', 'paid_message');
          break;

        case 'movies':
          /* get movie */
          $movie = $user->get_movie($transfer_request['movie_id']);
          /* movie payment */
          $user->movie_payment($transfer_request['movie_id'], $transfer_request['user_id']);
          /* log payment */
          $user->log_payment($transfer_request['user_id'], $transfer_request['price'], 'bank', 'movies');
          break;

        case 'marketplace':
          /* get orders collection */
          $orders_collection = $user->get_orders_collection($transfer_request['orders_collection_id']);
          /* mark order collection as paid */
          $user->mark_orders_collection_as_paid($transfer_request['orders_collection_id']);
          /* log payment */
          $user->log_payment($transfer_request['user_id'], $transfer_request['price'], 'bank', 'marketplace');
          break;

        default:
          _error(400);
          break;
      }
      /* approve request */
      $db->query(sprintf("UPDATE bank_transfers SET status = '1' WHERE transfer_id = %s", secure($_POST['id'], 'int')));
      /* notify the user */
      $user->post_notification(['to_user_id' => $transfer_request['user_id'], 'action' => 'bank_transfer_approved']);
      break;

    case 'decline':
      /* decline request */
      $db->query(sprintf("UPDATE bank_transfers SET status = '-1' WHERE transfer_id = %s", secure($_POST['id'], 'int')));
      /* notify the user */
      $user->post_notification(['to_user_id' => $transfer_request['user_id'], 'action' => 'bank_transfer_declined']);
      break;

    default:
      _error(400);
      break;
  }

  // return & exist
  return_json();
} catch (Exception $e) {
  modal("ERROR", __("Error"), $e->getMessage());
}
